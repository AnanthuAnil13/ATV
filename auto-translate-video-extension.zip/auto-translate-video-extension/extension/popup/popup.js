const DEFAULT_SETTINGS = {
  backendUrl: "http://localhost:8787",
  sourceLanguage: "ja",
  targetLanguage: "en",
  outputMode: "both",
  originalVolume: 0.15,
  dubVolume: 1,
  showSourceTranscript: false
};

const FALLBACK_LANGUAGES = [
  { code: "ja", label: "Japanese", canTarget: true },
  { code: "en", label: "English", canTarget: true },
  { code: "es", label: "Spanish", canTarget: true },
  { code: "pt", label: "Portuguese", canTarget: true },
  { code: "fr", label: "French", canTarget: true },
  { code: "ru", label: "Russian", canTarget: true },
  { code: "zh", label: "Chinese", canTarget: true },
  { code: "de", label: "German", canTarget: true },
  { code: "ko", label: "Korean", canTarget: true },
  { code: "hi", label: "Hindi", canTarget: true },
  { code: "id", label: "Indonesian", canTarget: true },
  { code: "vi", label: "Vietnamese", canTarget: true },
  { code: "it", label: "Italian", canTarget: true },
  { code: "nl", label: "Dutch", canTarget: false }
];

const els = {
  sourceLanguage: document.querySelector("#sourceLanguage"),
  targetLanguage: document.querySelector("#targetLanguage"),
  outputMode: document.querySelector("#outputMode"),
  originalVolume: document.querySelector("#originalVolume"),
  originalVolumeValue: document.querySelector("#originalVolumeValue"),
  dubVolume: document.querySelector("#dubVolume"),
  dubVolumeValue: document.querySelector("#dubVolumeValue"),
  showSourceTranscript: document.querySelector("#showSourceTranscript"),
  sourceTranscriptRow: document.querySelector("#sourceTranscriptRow"),
  modeNote: document.querySelector("#modeNote"),
  startButton: document.querySelector("#startButton"),
  stopButton: document.querySelector("#stopButton"),
  statusBadge: document.querySelector("#statusBadge"),
  message: document.querySelector("#message"),
  openOptions: document.querySelector("#openOptions")
};

init().catch((error) => showMessage(error.message, true));

async function init() {
  const settings = await chrome.storage.local.get(DEFAULT_SETTINGS);
  const languages = await loadLanguages(settings.backendUrl);
  populateLanguageSelects(languages, settings);

  els.outputMode.value = normalizeOutputMode(settings.outputMode);
  els.originalVolume.value = Math.round(clampVolume(settings.originalVolume) * 100);
  els.dubVolume.value = Math.round(clampVolume(settings.dubVolume) * 100);
  els.showSourceTranscript.checked = settings.showSourceTranscript;
  syncVolumeLabels();
  updateModeUi(false);

  els.startButton.addEventListener("click", startTranslation);
  els.stopButton.addEventListener("click", stopTranslation);
  els.openOptions.addEventListener("click", () => chrome.runtime.openOptionsPage());

  els.outputMode.addEventListener("change", async () => {
    applyModePreset(els.outputMode.value);
    updateModeUi(false);
    await persistControls();
  });
  els.showSourceTranscript.addEventListener("change", persistControls);
  els.sourceLanguage.addEventListener("change", persistControls);
  els.targetLanguage.addEventListener("change", persistControls);
  els.originalVolume.addEventListener("input", syncVolumeLabels);
  els.dubVolume.addEventListener("input", syncVolumeLabels);
  els.originalVolume.addEventListener("change", persistControls);
  els.dubVolume.addEventListener("change", persistControls);

  const stateResponse = await chrome.runtime.sendMessage({ type: "GET_TRANSLATION_STATE" });
  renderState(stateResponse?.state ?? { status: "idle" });

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === "session" && changes.translationState?.newValue) {
      renderState(changes.translationState.newValue);
    }
  });
}

async function loadLanguages(backendUrl) {
  try {
    const response = await fetch(`${backendUrl.replace(/\/$/, "")}/languages`);
    if (!response.ok) throw new Error("Language list unavailable");
    const data = await response.json();
    return Array.isArray(data.languages) && data.languages.length ? data.languages : FALLBACK_LANGUAGES;
  } catch {
    showMessage("Backend not reached yet. Using the built-in language list.");
    return FALLBACK_LANGUAGES;
  }
}

function populateLanguageSelects(languages, settings) {
  for (const language of languages) {
    els.sourceLanguage.add(new Option(language.label, language.code));
    if (language.canTarget === true) {
      els.targetLanguage.add(new Option(language.label, language.code));
    }
  }

  els.sourceLanguage.value = settings.sourceLanguage;
  els.targetLanguage.value = settings.targetLanguage;

  if (!els.sourceLanguage.value) els.sourceLanguage.value = "ja";
  if (!els.targetLanguage.value) els.targetLanguage.value = "en";
}

async function startTranslation() {
  try {
    if (els.sourceLanguage.value === els.targetLanguage.value) {
      throw new Error("Choose different video and translation languages.");
    }

    await persistControls();
    showMessage("Opening a realtime translation session…");
    els.startButton.disabled = true;

    const response = await chrome.runtime.sendMessage({
      type: "START_TRANSLATION",
      payload: {
        sourceLanguage: els.sourceLanguage.value,
        targetLanguage: els.targetLanguage.value,
        outputMode: els.outputMode.value,
        originalVolume: Number(els.originalVolume.value) / 100,
        dubVolume: Number(els.dubVolume.value) / 100,
        showSourceTranscript: els.showSourceTranscript.checked
      }
    });

    if (!response?.ok) {
      throw new Error(response?.error || "Could not start translation.");
    }
  } catch (error) {
    showMessage(error.message || "Could not start translation.", true);
    els.startButton.disabled = false;
  }
}

async function stopTranslation() {
  try {
    els.stopButton.disabled = true;
    const response = await chrome.runtime.sendMessage({ type: "STOP_TRANSLATION" });
    if (!response?.ok) {
      throw new Error(response?.error || "Could not stop translation.");
    }
  } catch (error) {
    showMessage(error.message || "Could not stop translation.", true);
    els.stopButton.disabled = false;
  }
}

async function persistControls() {
  await chrome.storage.local.set({
    sourceLanguage: els.sourceLanguage.value,
    targetLanguage: els.targetLanguage.value,
    outputMode: els.outputMode.value,
    originalVolume: Number(els.originalVolume.value) / 100,
    dubVolume: Number(els.dubVolume.value) / 100,
    showSourceTranscript: els.showSourceTranscript.checked
  });
}

function renderState(state) {
  const status = state.status || "idle";
  els.statusBadge.dataset.status = status;
  els.statusBadge.textContent = {
    idle: "Idle",
    starting: "Starting",
    connected: "Live",
    reconnecting: "Reconnecting",
    error: "Error"
  }[status] || status;

  const active = ["starting", "connected", "reconnecting"].includes(status);
  updateModeUi(active);
  els.startButton.disabled = active;
  els.stopButton.disabled = !active && status !== "error";
  els.sourceLanguage.disabled = active;
  els.targetLanguage.disabled = active;
  els.outputMode.disabled = active;
  els.originalVolume.disabled = active;

  if (status === "connected") {
    showMessage(`${modeLabel(state.outputMode || els.outputMode.value)} is live. Keep this video tab open.`);
  } else if (status === "reconnecting") {
    showMessage("The realtime connection is reconnecting…");
  } else if (status === "error") {
    showMessage(state.error || "The translation session failed.", true);
  } else if (status === "idle") {
    showMessage("Open a Japanese video, press play, choose a mode, then start.");
  }
}

function updateModeUi(active) {
  const mode = normalizeOutputMode(els.outputMode.value);
  const subtitlesEnabled = mode !== "dub";
  const dubEnabled = mode !== "subtitles";

  els.dubVolume.disabled = active || !dubEnabled;
  els.showSourceTranscript.disabled = active || !subtitlesEnabled;
  els.sourceTranscriptRow.dataset.disabled = String(!subtitlesEnabled);

  const copy = {
    both: {
      strong: "Subtitles and translated speech are both on.",
      detail: "The original track is mixed quietly underneath the English dub."
    },
    subtitles: {
      strong: "Original audio stays on.",
      detail: "Translated captions appear on the page; no AI voice is played."
    },
    dub: {
      strong: "Translated speech is on.",
      detail: "The original track is muted by default, but you can mix it back in."
    }
  }[mode];

  els.modeNote.innerHTML = `<strong>${copy.strong}</strong><span>${copy.detail}</span>`;
  els.startButton.textContent = {
    both: "Start subtitles + dub",
    subtitles: "Start subtitles",
    dub: "Start dub"
  }[mode];
}

function applyModePreset(mode) {
  const presets = {
    both: { original: 15, dub: 100 },
    subtitles: { original: 100, dub: 100 },
    dub: { original: 0, dub: 100 }
  };
  const preset = presets[normalizeOutputMode(mode)];
  els.originalVolume.value = preset.original;
  els.dubVolume.value = preset.dub;
  syncVolumeLabels();
}

function syncVolumeLabels() {
  els.originalVolumeValue.textContent = `${els.originalVolume.value}%`;
  els.dubVolumeValue.textContent = `${els.dubVolume.value}%`;
}

function normalizeOutputMode(value) {
  return ["subtitles", "dub", "both"].includes(value) ? value : "both";
}

function clampVolume(value) {
  const number = Number(value);
  return Number.isFinite(number) ? Math.min(1, Math.max(0, number)) : 1;
}

function modeLabel(mode) {
  return {
    both: "Subtitles + dub",
    subtitles: "Subtitles",
    dub: "Dub"
  }[normalizeOutputMode(mode)];
}

function showMessage(text, isError = false) {
  els.message.textContent = text;
  els.message.classList.toggle("error", isError);
}
