let session = null;

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.target !== "offscreen") return false;

  if (message.type === "OFFSCREEN_START") {
    startSession(message.payload)
      .then(() => sendResponse({ ok: true }))
      .catch(async (error) => {
        await stopSession({ notify: false });
        if (error.name !== "AbortError") {
          notifyStatus("error", { error: error.message, tabId: message.payload?.tabId });
        }
        sendResponse({ ok: false, error: error.message });
      });
    return true;
  }

  if (message.type === "OFFSCREEN_STOP") {
    stopSession({ notify: true })
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  return false;
});

async function startSession(config) {
  await stopSession({ notify: false });
  validateConfig(config);

  const currentSession = {
    config,
    hasConnected: false,
    sourceStream: null,
    sourceTrack: null,
    audioContext: null,
    sourceNode: null,
    originalGain: null,
    remoteAudio: null,
    peerConnection: null,
    events: null
  };
  session = currentSession;
  notifyStatus("starting", { tabId: config.tabId, outputMode: config.outputMode });

  currentSession.sourceStream = await navigator.mediaDevices.getUserMedia({
    audio: {
      mandatory: {
        chromeMediaSource: "tab",
        chromeMediaSourceId: config.streamId
      }
    },
    video: false
  });
  assertCurrentSession(currentSession);

  currentSession.sourceTrack = currentSession.sourceStream.getAudioTracks()[0];
  if (!currentSession.sourceTrack) {
    throw new Error("The captured tab did not provide an audio track.");
  }
  currentSession.sourceTrack.onended = () => {
    if (session !== currentSession) return;
    stopSession({ notify: true }).catch(console.error);
  };

  // tabCapture removes the tab's audio from its normal output path. Route the
  // captured track back through a gain node so it can be preserved, ducked, or
  // muted independently of the translated speech.
  currentSession.audioContext = new AudioContext();
  await currentSession.audioContext.resume();
  assertCurrentSession(currentSession);

  currentSession.sourceNode = currentSession.audioContext.createMediaStreamSource(currentSession.sourceStream);
  currentSession.originalGain = currentSession.audioContext.createGain();
  currentSession.originalGain.gain.value = clampVolume(config.originalVolume);
  currentSession.sourceNode.connect(currentSession.originalGain).connect(currentSession.audioContext.destination);

  const clientSecret = await requestClientSecret(config);
  assertCurrentSession(currentSession);

  currentSession.peerConnection = new RTCPeerConnection();
  currentSession.peerConnection.addTrack(currentSession.sourceTrack, currentSession.sourceStream);

  currentSession.peerConnection.ontrack = ({ track, streams }) => {
    if (session !== currentSession) return;

    if (!isDubEnabled(config.outputMode)) {
      track.enabled = false;
      return;
    }

    attachTranslatedAudio(currentSession, track, streams?.[0]);
  };

  currentSession.peerConnection.onconnectionstatechange = () => {
    if (session !== currentSession) return;
    const state = currentSession.peerConnection.connectionState;
    if (state === "connected") {
      currentSession.hasConnected = true;
      notifyStatus("connected", { tabId: config.tabId, outputMode: config.outputMode });
    } else if (state === "disconnected") {
      notifyStatus("reconnecting", { tabId: config.tabId, outputMode: config.outputMode });
    } else if (state === "connecting") {
      notifyStatus(currentSession.hasConnected ? "reconnecting" : "starting", {
        tabId: config.tabId,
        outputMode: config.outputMode
      });
    } else if (state === "failed") {
      notifyStatus("error", {
        tabId: config.tabId,
        outputMode: config.outputMode,
        error: "The realtime translation connection failed."
      });
    }
  };

  currentSession.events = currentSession.peerConnection.createDataChannel("oai-events");
  currentSession.events.onmessage = ({ data }) => handleRealtimeEvent(data, config);
  currentSession.events.onerror = () => {
    if (session !== currentSession) return;
    notifyStatus("error", {
      tabId: config.tabId,
      outputMode: config.outputMode,
      error: "The realtime translation event channel failed."
    });
  };

  const offer = await currentSession.peerConnection.createOffer();
  await currentSession.peerConnection.setLocalDescription(offer);
  assertCurrentSession(currentSession);

  const sdpResponse = await fetch("https://api.openai.com/v1/realtime/translations/calls", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${clientSecret}`,
      "Content-Type": "application/sdp"
    },
    body: offer.sdp
  });
  assertCurrentSession(currentSession);

  if (!sdpResponse.ok) {
    throw new Error(`OpenAI WebRTC connection failed (${sdpResponse.status}): ${await sdpResponse.text()}`);
  }

  const answerSdp = await sdpResponse.text();
  assertCurrentSession(currentSession);
  await currentSession.peerConnection.setRemoteDescription({
    type: "answer",
    sdp: answerSdp
  });
  assertCurrentSession(currentSession);
}

function attachTranslatedAudio(currentSession, track, suppliedStream) {
  track.enabled = true;
  const translatedStream = suppliedStream || new MediaStream([track]);
  const audio = document.createElement("audio");
  audio.autoplay = true;
  audio.playsInline = true;
  audio.hidden = true;
  audio.volume = clampVolume(currentSession.config.dubVolume);
  audio.srcObject = translatedStream;
  document.body.appendChild(audio);
  currentSession.remoteAudio = audio;

  audio.play().catch((error) => {
    if (session !== currentSession || error.name === "AbortError") return;
    notifyStatus("error", {
      tabId: currentSession.config.tabId,
      outputMode: currentSession.config.outputMode,
      error: "The translated audio track was received but could not be played."
    });
  });
}

async function requestClientSecret(config) {
  const response = await fetch(`${config.backendUrl}/session`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      sourceLanguage: config.sourceLanguage,
      targetLanguage: config.targetLanguage,
      showSourceTranscript: config.showSourceTranscript,
      installationId: config.installationId
    })
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.error || `The AutoTranslate backend returned ${response.status}.`);
  }

  if (!data.value || typeof data.value !== "string") {
    throw new Error("The backend did not return a valid short-lived client secret.");
  }

  return data.value;
}

function handleRealtimeEvent(rawData, config) {
  let event;
  try {
    event = JSON.parse(rawData);
  } catch {
    return;
  }

  if (event.type === "session.output_transcript.delta" && event.delta) {
    notifyTranscript({
      tabId: config.tabId,
      kind: "target",
      delta: event.delta,
      elapsedMs: event.elapsed_ms
    });
  }

  if (event.type === "session.input_transcript.delta" && event.delta) {
    notifyTranscript({
      tabId: config.tabId,
      kind: "source",
      delta: event.delta,
      elapsedMs: event.elapsed_ms
    });
  }

  if (event.type === "error") {
    const message = event.error?.message || "The realtime translation service returned an error.";
    notifyStatus("error", { tabId: config.tabId, outputMode: config.outputMode, error: message });
  }
}

async function stopSession({ notify }) {
  if (!session) {
    if (notify) notifyStatus("idle", {});
    return;
  }

  const oldSession = session;
  session = null;

  try { oldSession.events?.close(); } catch {}
  try { oldSession.peerConnection?.close(); } catch {}
  try { oldSession.sourceStream?.getTracks().forEach((track) => track.stop()); } catch {}
  try {
    if (oldSession.remoteAudio) {
      oldSession.remoteAudio.pause();
      oldSession.remoteAudio.srcObject = null;
      oldSession.remoteAudio.remove();
    }
  } catch {}
  try { await oldSession.audioContext?.close(); } catch {}

  if (notify) {
    notifyStatus("idle", { tabId: oldSession.config?.tabId ?? null });
  }
}

function notifyStatus(status, extra) {
  chrome.runtime.sendMessage({
    type: "OFFSCREEN_STATUS",
    payload: { status, ...extra }
  }).catch(() => null);
}

function notifyTranscript(payload) {
  chrome.runtime.sendMessage({
    type: "OFFSCREEN_TRANSCRIPT",
    payload
  }).catch(() => null);
}

function assertCurrentSession(expectedSession) {
  if (session !== expectedSession) {
    throw new DOMException("Translation start was cancelled.", "AbortError");
  }
}

function validateConfig(config) {
  if (!config?.streamId) throw new Error("Missing tab audio stream ID.");
  if (!config?.backendUrl) throw new Error("Missing AutoTranslate backend URL.");
  if (!config?.targetLanguage) throw new Error("Missing translation language.");
  if (!config?.tabId) throw new Error("Missing active tab ID.");
  if (!["subtitles", "dub", "both"].includes(config?.outputMode)) {
    throw new Error("Invalid translation output mode.");
  }
}

function isDubEnabled(outputMode) {
  return outputMode === "dub" || outputMode === "both";
}

function clampVolume(value) {
  const number = Number(value);
  return Number.isFinite(number) ? Math.min(1, Math.max(0, number)) : 1;
}
