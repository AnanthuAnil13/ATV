# AutoTranslate Video: Subtitles + Dub

A Chromium browser extension that captures the active video tab's audio and translates it live. The default language pair is **Japanese → English**, and the language list is driven by one backend registry so it is easy to extend.

Version 0.3 adds three selectable output modes:

1. **Subtitles + dub** — translated captions and translated speech together; original audio is ducked to 15% by default.
2. **Subtitles only** — translated captions with the original audio preserved at full volume.
3. **Dub only** — translated speech with the original audio muted by default.

The original and translated audio levels can be adjusted independently before a session starts.

## What is included

- `extension/` — Chrome/Edge/Brave Manifest V3 extension
- `server/` — small Node.js backend that issues short-lived OpenAI Realtime Translation client secrets
- live translated speech from the remote WebRTC audio track
- live translated subtitles from Realtime transcript events
- optional source-language transcript above the translation
- independent original-audio and dub-volume controls
- language registry in `server/src/languages.js`
- no OpenAI API key stored in the extension

## Architecture

```text
Video tab audio
      │
      ▼
Chrome tabCapture
      │
      ├── original audio ──► gain control ──────────────► speakers
      │
      ▼
Extension offscreen document
      │  WebRTC source audio track
      ▼
OpenAI Realtime Translation
      │
      ├── translated audio track ──► dub volume ────────► speakers
      ├── translated transcript deltas ─────────────────► subtitle overlay
      └── optional source transcript ────────────────────► subtitle overlay

Extension ──► local backend ──► short-lived client secret
                         (the backend never receives tab audio)
```

## Requirements

- Chrome, Microsoft Edge, Brave, or another Chromium browser based on Chrome 116+
- Node.js 20+
- an OpenAI API key with access to Realtime Translation

## Setup

### 1. Start the backend

```bash
cd server
cp .env.example .env
```

Edit `.env` and set:

```dotenv
OPENAI_API_KEY=<your-openai-api-key>
SAFETY_ID_SALT=use-a-long-random-value
```

Then run:

```bash
npm install
npm start
```

The backend should print:

```text
AutoTranslate session server listening on http://localhost:8787
```

Check it:

```bash
curl http://localhost:8787/health
```

### 2. Load the extension

1. Open `chrome://extensions`.
2. Enable **Developer mode**.
3. Click **Load unpacked**.
4. Select the `extension` folder from this project.

### 3. Translate a video

1. Open a webpage with a Japanese video.
2. Start the video.
3. Click the AutoTranslate extension icon.
4. Keep **Japanese → English** selected.
5. Choose **Subtitles + dub**, **Subtitles only**, or **Dub only**.
6. Adjust the original-audio and translated-dub volume sliders as needed.
7. Optionally enable **Also show the source-language transcript** when using a subtitle mode.
8. Click the start button.

In subtitle modes, English captions appear near the bottom of the page. Click the small **×** in the overlay to hide the captions without stopping translation, or use **Stop** in the popup to end the session.

## Output-mode behavior

| Mode | Subtitles | Translated speech | Default original audio |
|---|---:|---:|---:|
| Subtitles + dub | Yes | Yes | 15% |
| Subtitles only | Yes | No | 100% |
| Dub only | No | Yes | 0% |

The volume sliders are applied when the session starts. To change the mix, stop the current session, adjust the levels, and start again.

## Add more languages

Edit only `server/src/languages.js`:

```js
export const LANGUAGES = Object.freeze([
  // existing languages...
  { code: "sv", label: "Swedish", canTarget: false }
]);
```

Restart the backend. The extension fetches `GET /languages` each time its popup opens, so the new language appears without changing extension code. Use `canTarget: true` only for languages currently supported as Realtime Translation outputs; input-only languages should use `canTarget: false`.

The Realtime Translation endpoint auto-detects the incoming language. The **Video language** selector is retained as user-facing metadata and for future language-specific behavior; the selected **Translation language** configures both the translated audio and translated subtitle output.

## How subtitle cues work

Realtime Translation emits append-only transcript deltas while speech is arriving. AutoTranslate displays those deltas immediately, starts a fresh cue after a detected timing gap, keeps only the latest text when speech is continuous, and clears stale captions after a short pause.

This provides low-latency live captions, but it is not the same as a professionally timed SRT/VTT subtitle track.

## How dubbing works

The browser sends the captured tab-audio track to the Realtime Translation session over WebRTC. The translated speech arrives as a remote WebRTC audio track and is played by the extension's offscreen document. The original tab audio is separately routed through a Web Audio gain node, allowing the source and translated speech to be mixed independently.

The current Realtime Translation model does not expose custom prompting or voice-selection parameters, so this version does not include a voice picker.

## Remote backend deployment

The default backend URL is `http://localhost:8787`. To use a remote backend:

1. Deploy `server/` behind HTTPS.
2. Set a restrictive `ALLOWED_ORIGINS` value instead of `*`.
3. Open **Backend settings** in the extension.
4. Enter the HTTPS backend URL and approve the browser's origin-permission prompt.

For production, also add authentication, persistent distributed rate limiting, request logging that avoids sensitive content, monitoring, and abuse controls.

## Limitations

- Live captions and speech have network/model latency and will not be frame-perfect or lip-synchronized.
- Music, sound effects, overlapping speakers, fast dialogue, names, and specialized vocabulary can reduce translation quality.
- The model receives the mixed tab audio, so clean dialogue tracks work best.
- The source/dub mix can create an echo-like experience if the original volume is set too high in a dub mode.
- Browser-internal pages cannot be captured. Some protected/DRM media may provide silence or block capture.
- The overlay works in normal page mode and on common sites whose fullscreen element is a container. Native fullscreen directly on a `<video>` element may hide page overlays.
- One extension session translates into one target language at a time.
- The extension targets Chromium Manifest V3. Firefox needs a separate port because its extension media-capture APIs differ.

## Privacy and disclosure

While translation is active, captured tab audio is sent directly from the extension to OpenAI over WebRTC. The included backend receives the chosen language codes, the source-transcript preference, and a random installation identifier, then returns a short-lived client secret; it does not receive the video audio.

The overlay and popup clearly disclose that the live translation is AI-generated.

## Development checks

```bash
cd server
npm run check
```

You can also validate the extension manifest with:

```bash
python -m json.tool ../extension/manifest.json > /dev/null
```

## Reference documentation

- OpenAI Realtime Translation: https://developers.openai.com/api/docs/guides/realtime-translation
- OpenAI live translation cookbook: https://developers.openai.com/cookbook/examples/voice_solutions/realtime_translation_guide
- OpenAI translation server events: https://developers.openai.com/api/reference/resources/realtime/translation-server-events/
- OpenAI Realtime WebRTC: https://developers.openai.com/api/docs/guides/realtime-webrtc
- Chrome content scripts: https://developer.chrome.com/docs/extensions/develop/concepts/content-scripts
- Chrome tab capture: https://developer.chrome.com/docs/extensions/reference/api/tabCapture
- Chrome offscreen documents: https://developer.chrome.com/docs/extensions/reference/api/offscreen

## Project status

Version `0.3.0` is designed for local installation and testing. Before publishing in an extension store, add a privacy policy, production backend authentication, telemetry opt-in, automated browser tests, accessibility testing, and store-specific packaging.
