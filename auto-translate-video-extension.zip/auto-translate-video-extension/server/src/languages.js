/**
 * Language registry for the extension UI and backend validation.
 *
 * To add a new source language, add an object with `canTarget: false`.
 * Set `canTarget: true` only when the current Realtime Translation model
 * supports that language for translated audio and transcript output. The extension fetches this
 * list from GET /languages, so no extension code changes are required.
 */
export const LANGUAGES = Object.freeze([
  { code: "ja", label: "Japanese", canTarget: true },
  { code: "en", label: "English", canTarget: true },
  { code: "es", label: "Spanish", canTarget: true },
  { code: "pt", label: "Portuguese", canTarget: true },
  { code: "fr", label: "French", canTarget: true },
  { code: "ru", label: "Russian", canTarget: true },
  { code: "zh", label: "Chinese", canTarget: true },
  { code: "de", label: "German", canTarget: true },
  { code: "ko", label: "Korean", canTarget: true },
  { code: "hi", label: "Hindi", canTarget: true },
  { code: "id", label: "Indonesian", canTarget: true },
  { code: "vi", label: "Vietnamese", canTarget: true },
  { code: "it", label: "Italian", canTarget: true },
  { code: "nl", label: "Dutch", canTarget: false }
]);

export const LANGUAGE_CODES = new Set(LANGUAGES.map(({ code }) => code));
export const TARGET_LANGUAGE_CODES = new Set(
  LANGUAGES.filter(({ canTarget }) => canTarget).map(({ code }) => code)
);
