import crypto from "node:crypto";
import process from "node:process";
import cors from "cors";
import dotenv from "dotenv";
import express from "express";
import { LANGUAGES, LANGUAGE_CODES, TARGET_LANGUAGE_CODES } from "./languages.js";

dotenv.config();

const app = express();
const port = Number(process.env.PORT || 8787);
const openAiApiKey = process.env.OPENAI_API_KEY;
const safetySalt = process.env.SAFETY_ID_SALT || "autotranslate-development-only-salt";
const allowedOrigins = parseAllowedOrigins(process.env.ALLOWED_ORIGINS || "*");
const rateBuckets = new Map();

app.disable("x-powered-by");
app.use(express.json({ limit: "16kb" }));
app.use(cors({
  origin(origin, callback) {
    if (!origin || allowedOrigins === "*" || allowedOrigins.has(origin)) {
      callback(null, true);
      return;
    }
    callback(new Error("Origin is not allowed by this AutoTranslate backend."));
  },
  methods: ["GET", "POST", "OPTIONS"]
}));

app.get("/health", (req, res) => {
  res.json({ ok: true, service: "autotranslate-session-server" });
});

app.get("/languages", (req, res) => {
  res.json({ languages: LANGUAGES });
});

app.post("/session", async (req, res) => {
  try {
    if (!openAiApiKey) {
      return res.status(503).json({ error: "OPENAI_API_KEY is not configured on the AutoTranslate backend." });
    }

    if (!consumeRateLimit(getClientKey(req))) {
      return res.status(429).json({ error: "Too many session requests. Try again later." });
    }

    // Source language is retained as validated user-facing metadata. The
    // translation endpoint auto-detects the incoming language.
    const sourceLanguage = sanitizeLanguage(req.body?.sourceLanguage, "ja");
    const targetLanguage = sanitizeTargetLanguage(req.body?.targetLanguage, "en");
    if (sourceLanguage === targetLanguage) {
      return res.status(400).json({ error: "Source and translation languages must be different." });
    }

    const showSourceTranscript = req.body?.showSourceTranscript === true;
    const safetyIdentifier = hashSafetyIdentifier(req.body?.installationId);
    const audio = {
      output: {
        language: targetLanguage
      }
    };

    if (showSourceTranscript) {
      audio.input = {
        transcription: {
          model: "gpt-realtime-whisper"
        }
      };
    }

    const openAiResponse = await fetch(
      "https://api.openai.com/v1/realtime/translations/client_secrets",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${openAiApiKey}`,
          "Content-Type": "application/json",
          "OpenAI-Safety-Identifier": safetyIdentifier
        },
        body: JSON.stringify({
          session: {
            model: "gpt-realtime-translate",
            audio
          }
        })
      }
    );

    const responseBody = await openAiResponse.json().catch(async () => ({
      error: { message: await openAiResponse.text().catch(() => "Unknown OpenAI error") }
    }));

    if (!openAiResponse.ok) {
      const message = responseBody?.error?.message || "OpenAI could not create a realtime translation session.";
      return res.status(openAiResponse.status).json({ error: message });
    }

    // Return only the short-lived client secret response. The standard API key
    // never leaves this server.
    return res.status(201).json(responseBody);
  } catch (error) {
    console.error("Session creation failed:", error);
    const statusCode = Number.isInteger(error.statusCode) ? error.statusCode : 500;
    const message = statusCode < 500
      ? error.message
      : "The AutoTranslate backend could not create a session.";
    return res.status(statusCode).json({ error: message });
  }
});

app.use((error, req, res, next) => {
  console.error(error);
  res.status(403).json({ error: error.message || "Request rejected." });
});

app.listen(port, () => {
  console.log(`AutoTranslate session server listening on http://localhost:${port}`);
});

function sanitizeLanguage(value, fallback) {
  const code = typeof value === "string" ? value.trim().toLowerCase() : fallback;
  if (!LANGUAGE_CODES.has(code)) {
    const error = new Error(`Unsupported language code: ${code}`);
    error.statusCode = 400;
    throw error;
  }
  return code;
}

function sanitizeTargetLanguage(value, fallback) {
  const code = typeof value === "string" ? value.trim().toLowerCase() : fallback;
  if (!TARGET_LANGUAGE_CODES.has(code)) {
    const error = new Error(`Unsupported translation language code: ${code}`);
    error.statusCode = 400;
    throw error;
  }
  return code;
}

function hashSafetyIdentifier(installationId) {
  const stableId = typeof installationId === "string" && installationId.length <= 128
    ? installationId
    : "anonymous-installation";
  return crypto.createHash("sha256").update(`${safetySalt}:${stableId}`).digest("hex");
}

function parseAllowedOrigins(value) {
  if (value.trim() === "*") return "*";
  return new Set(value.split(",").map((origin) => origin.trim()).filter(Boolean));
}

function getClientKey(req) {
  return req.ip || req.socket.remoteAddress || "unknown";
}

function consumeRateLimit(key) {
  const now = Date.now();
  const windowMs = 60 * 60 * 1000;
  const maxRequests = 30;
  const existing = rateBuckets.get(key);

  if (!existing || now - existing.startedAt >= windowMs) {
    rateBuckets.set(key, { startedAt: now, count: 1 });
    return true;
  }

  existing.count += 1;
  return existing.count <= maxRequests;
}
